# interpolation linéaire
def lerp(t, frm, to):
    return (1 - t) * frm + t*to