const = {
    "FPS" : 60, # FPS du jeu
    "SCREEN_SIZE" : (900, 600), # Taille de l'écran
    "BACKGROUND_COLOR" : (0, 0, 0),
    "CHUNCK_SIZE" : 10, # So the tiles width will be SCREEN_SIZE[0] / CHUNCK_SIZE
    "DEBUG_MODE_ENABLED" : True,
}